class AppEndPoints {
  static const String endPoint = 'https://volty.barmajha.com/backend/public';

  // authentication
  static const String createUser = '$endPoint/auth/register.php';
  static const String loginUser = '$endPoint/auth/login.php';
  static const String tokenChecker = '$endPoint/auth/check.php';
  static const String changePassword = '$endPoint/auth/change_password.php';
  static const String resetPassword = '$endPoint/auth/reset_password.php';

  // App
  static const String showConfigs = '$endPoint/app/configs.php';
  static const String fetchAppPlans = '$endPoint/app/show_plans.php';

  // products
  static const String showProducts = '$endPoint/products/show_products.php';
  static const String addProduct = '$endPoint/products/add_product.php';
  static const String addProductBulk =
      '$endPoint/products/add_product_bulk.php';
  static const String addCategory = '$endPoint/products/add_category.php';
  static const String updateProduct = '$endPoint/products/update_product.php';
  static const String deleteProduct = '$endPoint/products/delete_product.php';

  // Transactions
  static const String createTransaction =
      '$endPoint/cashier/create_transaction.php';
  static const String alterTransaction =
      '$endPoint/cashier/alter_transaction.php';
  static const String alterItem = '$endPoint/cashier/alter_item.php';
  static const String showTransactions =
      '$endPoint/cashier/show_transactions.php';

  // clients
  static const String showClients = '$endPoint/clients/show_clients.php';
  static const String showClientStatement =
      '$endPoint/clients/client_statement.php';
  static const String showClientHistory =
      '$endPoint/clients/show_client_history.php';
  static const String addClient = '$endPoint/clients/add_client.php';
  static const String deleteClient = '$endPoint/clients/delete_client.php';
  static const String editClient = '$endPoint/clients/edit_client.php';
  static const String checkinClient = '$endPoint/clients/checkin_client.php';
  static const String enrollClient = '$endPoint/clients/enroll_client.php';

  // treasury
  static const String treasuryRequest =
      '$endPoint/treasury/treasury_request.php';
  static const String showTreasury = '$endPoint/treasury/show_treasury.php';

  // Employees
  static const String createEmployee =
      '$endPoint/employees/create_employee.php';
  static const String showEmployees = '$endPoint/employees/show_employees.php';
  static const String payEmployee = '$endPoint/employees/pay_employee.php';
  static const String attendEmployee =
      '$endPoint/employees/attend_employee.php';
  static const String generateQr = '$endPoint/employees/attendance_qr.php';
  static const String updateEmployee =
      '$endPoint/employees/update_employee.php';
  static const String updateVendor = '$endPoint/employees/update_vendor.php';

  // Reports
  static const String showReports = '$endPoint/reports/show_reports.php';

  // Plans
  static const String showPlans = '$endPoint/plans/show_plans.php';
  static const String addPlan = '$endPoint/plans/add_plan.php';
  static const String editPlan = '$endPoint/plans/edit_plan.php';
  static const String controlPlan = '$endPoint/plans/control_plan.php';
}
