import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/date_symbol_data_local.dart';
import '../views/auth/error_screen.dart';
import 'app_globals.dart';
import 'app_localization.dart';
import 'app_navigator.dart';
import 'app_shared.dart';

class AppPresets {
  static late String appVersion;
  static init() async {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.blueGrey,
        systemNavigationBarDividerColor: Colors.transparent,
      ),
    );
    AppLocalization.init();

    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    await AppShared.init();
    await initializeDateFormatting('ar_EG', null);
    Intl.defaultLocale = 'ar_EG';
  }

  static Future<bool> initData(BuildContext context) async {
    await Future.wait([
      // BlocProvider.of<ProductsCubit>(context).fetchProducts(),
    ]);
    if (!AppGlobals.isModelsInitialized()) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => AppNavigator.pushR(
          context,
          ErrorScreen(
            errorMsg: AppGlobals.isModelsInitialized()
                ? ""
                : "برجاء تفقد الإتصال بلشبكة",
            icon: AppGlobals.isModelsInitialized()
                ? FontAwesomeIcons.tools
                : Icons.signal_wifi_connected_no_internet_4_sharp,
          ),
          NavigatorAnimation.slideAnimation,
        ),
      );
      return false;
    }
    return true;
  }
}
