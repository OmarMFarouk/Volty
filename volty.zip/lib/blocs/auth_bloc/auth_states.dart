abstract class AuthStates {}

class AuthInitial extends AuthStates {}

class AuthRefresh extends AuthStates {}

class AuthLoading extends AuthStates {}

class AuthSuccess extends AuthStates {
  String msg = '';
  bool shouldNavigate;
  AuthSuccess({required this.msg, this.shouldNavigate = true});
}

class AuthError extends AuthStates {
  String msg = '';
  AuthError({required this.msg});
}
