// import 'package:cashiery_mobile/components/general/my_animation.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:cashiery_mobile/src/app_presets.dart';
// import 'package:url_launcher/url_launcher.dart';
// import '../../src/app_colors.dart';

// class UpdateDialog extends StatefulWidget {
//   final String version;
//   final String? title;
//   final String? description;
//   final List<String>? features;
//   final String? updateLink;
//   final VoidCallback? onLater;
//   final bool isForced;

//   const UpdateDialog({
//     super.key,
//     required this.version,
//     this.title,
//     this.description,
//     this.features,
//     this.updateLink,
//     this.onLater,
//     this.isForced = false,
//   });

//   @override
//   State<UpdateDialog> createState() => _UpdateDialogState();
// }

// class _UpdateDialogState extends State<UpdateDialog> {
//   bool _isUpdating = false;

//   Future<void> _handleUpdate() async {
//     setState(() => _isUpdating = true);

//     // Simulate update process - replace with actual update logic
//     await Future.delayed(const Duration(seconds: 2));
//     launchUrl(
//       Uri.parse(widget.updateLink ?? "https://play.google.com/"),
//       mode: LaunchMode.externalApplication,
//     );
//   }

//   void _handleLater() {
//     if (widget.onLater != null) {
//       widget.onLater!();
//     }
//     Navigator.of(context).pop();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final screenHeight = MediaQuery.of(context).size.height;

//     return PopScope(
//       canPop: !widget.isForced,
//       child: Dialog(
//         backgroundColor: Colors.transparent,
//         insetPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
//         child: MyCustomAnimation(
//           duration: 750,
//           child: Container(
//             constraints: BoxConstraints(
//               maxHeight: screenHeight * 0.8,
//               maxWidth: double.infinity,
//             ),
//             decoration: BoxDecoration(
//               gradient: const LinearGradient(
//                 colors: AppColors.quintupleGradient,
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: AppColors.primary.withOpacity(0.3),
//                 width: 1,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: AppColors.primary.withOpacity(0.2),
//                   spreadRadius: 0,
//                   blurRadius: 20,
//                   offset: const Offset(0, 10),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.3),
//                   spreadRadius: 0,
//                   blurRadius: 40,
//                   offset: const Offset(0, 20),
//                 ),
//               ],
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 _buildHeader(),
//                 _buildUpdateIcon(),
//                 _buildVersionInfo(),
//                 if (widget.features != null && widget.features!.isNotEmpty)
//                   _buildFeatures(),
//                 _buildDescription(),
//                 _buildActionButtons(),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildHeader() {
//     return Container(
//       padding: EdgeInsets.all(20),
//       child: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               gradient: const LinearGradient(colors: AppColors.primaryGradient),
//               borderRadius: BorderRadius.circular(12),
//               boxShadow: [
//                 BoxShadow(
//                   color: AppColors.primary.withOpacity(0.3),
//                   spreadRadius: 0,
//                   blurRadius: 8,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Icon(
//               FontAwesomeIcons.download,
//               color: Colors.white,
//               size: 20,
//             ),
//           ),
//           const SizedBox(width: 16),
//           Expanded(
//             child: Column(
//               textDirection: TextDirection.rtl,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   widget.title ?? 'تحديث جديد متاح',
//                   style: TextStyle(
//                     fontSize: 18,
//                     fontWeight: FontWeight.bold,
//                     color: AppColors.primaryFont,
//                   ),
//                 ),
//                 const SizedBox(height: 4),
//                 Text(
//                   'الإصدار الحالي ${AppPresets.appVersion}',
//                   style: TextStyle(
//                     fontSize: 12,
//                     color: AppColors.primaryFont.withOpacity(0.7),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           if (!widget.isForced)
//             IconButton(
//               onPressed: _handleLater,
//               icon: Icon(
//                 Icons.close,
//                 color: AppColors.primaryFont.withOpacity(0.7),
//                 size: 24,
//               ),
//             ),
//         ],
//       ),
//     );
//   }

//   Widget _buildUpdateIcon() {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 20),
//       padding: EdgeInsets.all(30),
//       child: Container(
//         width: 85,
//         height: 85,
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(15),
//           image: DecorationImage(
//             image: AssetImage('assets/images/logo.png'),
//             scale: 6.5,
//           ),
//           gradient: const LinearGradient(colors: AppColors.primaryGradient),
//           boxShadow: [
//             BoxShadow(
//               color: AppColors.primary.withOpacity(0.3),
//               spreadRadius: 0,
//               blurRadius: 20,
//               offset: const Offset(0, 8),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildVersionInfo() {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 20),
//       padding: EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppColors.primary.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.primary.withOpacity(0.3), width: 1),
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(Icons.new_releases, color: AppColors.primary, size: 20),
//           const SizedBox(width: 12),
//           Text(
//             'إصدار جديد ${widget.version}',
//             style: TextStyle(
//               color: AppColors.primary,
//               fontSize: 16,
//               fontWeight: FontWeight.bold,
//             ),
//             textDirection: TextDirection.rtl,
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildFeatures() {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Container(
//         margin: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
//         padding: EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           color: AppColors.orange.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: AppColors.orange.withOpacity(0.2),
//             width: 1,
//           ),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Icon(Icons.star, color: AppColors.orange, size: 20),
//                 const SizedBox(width: 8),
//                 Text(
//                   'ما الجديد:',
//                   style: TextStyle(
//                     color: AppColors.orange,
//                     fontSize: 14,
//                     fontWeight: FontWeight.bold,
//                   ),
//                   textDirection: TextDirection.rtl,
//                 ),
//               ],
//             ),
//             const SizedBox(height: 12),
//             ...widget.features!
//                 .map(
//                   (feature) => Padding(
//                     padding: const EdgeInsets.only(bottom: 8),
//                     child: Row(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Container(
//                           margin: const EdgeInsets.only(top: 6),
//                           width: 4,
//                           height: 4,
//                           decoration: BoxDecoration(
//                             color: AppColors.orange,
//                             shape: BoxShape.circle,
//                           ),
//                         ),
//                         const SizedBox(width: 12),
//                         Expanded(
//                           child: Text(
//                             feature,
//                             style: TextStyle(
//                               color: AppColors.orange.withOpacity(0.9),
//                               fontSize: 12,
//                               height: 1.4,
//                             ),
//                             textDirection: TextDirection.rtl,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 )
//                 .toList(),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildDescription() {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
//       padding: EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: AppColors.orange.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Row(
//         children: [
//           Icon(Icons.info_outline, color: AppColors.orange, size: 20),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(
//               widget.description ?? 'احصل على أحدث الميزات والتحسينات',
//               style: TextStyle(
//                 color: AppColors.orange,
//                 fontSize: 12,
//                 fontWeight: FontWeight.w600,
//               ),
//               textDirection: TextDirection.rtl,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildActionButtons() {
//     return Container(
//       padding: EdgeInsets.all(20),
//       child: Column(
//         children: [
//           // Main action buttons
//           Row(
//             children: [
//               if (!widget.isForced) ...[
//                 Expanded(
//                   child: _buildActionButton(
//                     onPressed: _isUpdating ? null : _handleLater,
//                     icon: Icons.schedule,
//                     label: 'لاحقاً',
//                     isPrimary: false,
//                     isOutlined: true,
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//               ],
//               Expanded(
//                 flex: widget.isForced ? 1 : 1,
//                 child: _buildActionButton(
//                   onPressed: _isUpdating ? null : _handleUpdate,
//                   icon: _isUpdating
//                       ? Icons.downloading
//                       : FontAwesomeIcons.download,
//                   label: _isUpdating ? 'جاري التحديث...' : 'تحديث الآن',
//                   isPrimary: true,
//                   isOutlined: false,
//                 ),
//               ),
//             ],
//           ),

//           // Loading indicator
//           if (_isUpdating) ...[
//             const SizedBox(height: 16),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 SizedBox(
//                   width: 16,
//                   height: 16,
//                   child: CircularProgressIndicator(
//                     strokeWidth: 2,
//                     valueColor: AlwaysStoppedAnimation<Color>(
//                       AppColors.primary,
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   'يرجى الانتظار...',
//                   style: TextStyle(
//                     color: AppColors.primaryFont.withOpacity(0.7),
//                     fontSize: 12,
//                   ),
//                   textDirection: TextDirection.rtl,
//                 ),
//               ],
//             ),
//           ],
//         ],
//       ),
//     );
//   }

//   Widget _buildActionButton({
//     required VoidCallback? onPressed,
//     required IconData icon,
//     required String label,
//     required bool isPrimary,
//     bool isOutlined = false,
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: isPrimary && !isOutlined
//             ? const LinearGradient(colors: AppColors.primaryGradient)
//             : null,
//         borderRadius: BorderRadius.circular(12),
//         border: isOutlined
//             ? Border.all(color: AppColors.primary.withOpacity(0.5), width: 1)
//             : null,
//         boxShadow: isPrimary && !isOutlined
//             ? [
//                 BoxShadow(
//                   color: AppColors.primary.withOpacity(0.3),
//                   spreadRadius: 0,
//                   blurRadius: 8,
//                   offset: const Offset(0, 2),
//                 ),
//               ]
//             : null,
//       ),
//       child: ElevatedButton.icon(
//         onPressed: onPressed,
//         icon: Icon(
//           icon,
//           color: isPrimary && !isOutlined ? Colors.white : AppColors.primary,
//           size: 16,
//         ),
//         label: Text(
//           label,
//           style: TextStyle(
//             color: isPrimary && !isOutlined ? Colors.white : AppColors.primary,
//             fontSize: 14,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         style: ElevatedButton.styleFrom(
//           backgroundColor: isPrimary && !isOutlined
//               ? Colors.transparent
//               : isOutlined
//               ? Colors.transparent
//               : AppColors.secondary,
//           shadowColor: Colors.transparent,
//           padding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(12),
//           ),
//         ),
//       ),
//     );
//   }
// }

// // Helper function to show the Update dialog
// class UpdateDialogHelper {
//   static Future<void> show({
//     required BuildContext context,
//     required String version,
//     String? title,
//     String? description,
//     List<String>? features,
//     String? link,
//     VoidCallback? onLater,
//     bool isForced = false,
//   }) {
//     return showDialog<void>(
//       context: context,
//       barrierDismissible: isForced,
//       barrierColor: Colors.black.withOpacity(0.7),
//       builder: (BuildContext context) {
//         return UpdateDialog(
//           version: version,
//           title: title,
//           description: description,
//           features: features,
//           updateLink: link,
//           onLater: onLater,
//           isForced: isForced,
//         );
//       },
//     );
//   }
// }
