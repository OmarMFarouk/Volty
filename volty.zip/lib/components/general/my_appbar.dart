import 'package:flutter/material.dart';

import '../../src/app_colors.dart';

class MyAppBar extends StatelessWidget {
  const MyAppBar({super.key, required this.icon, required this.title});

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, color: AppColors.backGround),
          Text(title, style: const TextStyle(color: AppColors.backGround)),
        ],
      ),
      backgroundColor: Colors.teal[800],
    );
  }
}
