// import 'package:cashiery_mobile/blocs/products_bloc/products_cubit.dart';
// import 'package:cashiery_mobile/src/app_responsive.dart';
// import 'package:flutter/material.dart';
// import 'package:cashiery_mobile/src/app_colors.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// import '../../enums/permissions_enum.dart';
// import '../../src/app_globals.dart';
// import '../product_screen/excel_sheet.dart';

// class MyBar extends StatelessWidget {
//   const MyBar({
//     super.key,
//     required this.title,
//     required this.subtitle,
//     this.actionTitle,
//     this.onAction,
//     required this.icon,
//   });
//   final String title, subtitle;
//   final String? actionTitle;
//   final IconData icon;
//   final VoidCallback? onAction;
//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.ltr,
//       child: Container(
//         height: onAction != null
//             ? kToolbarHeight * (context.isSmall ? 2.2 : 2.7)
//             : kToolbarHeight * (context.isSmall ? 1.3 : 1.8),
//         width: double.infinity,
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: AppColors.primaryGradient,
//           ),
//         ),
//         child: Stack(
//           children: [
//             if (onAction != null)
//               Positioned(
//                 top: 10,
//                 right: 10,
//                 child: Material(
//                   color: Colors.transparent,
//                   borderRadius: BorderRadius.circular(12),
//                   child: InkWell(
//                     onTap: onAction,
//                     borderRadius: BorderRadius.circular(12),
//                     child: Ink(
//                       padding: const EdgeInsets.symmetric(
//                         horizontal: 10,
//                         vertical: 5,
//                       ),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(15),
//                         border: Border.all(
//                           color: AppColors.primary.withOpacity(0.5),
//                           width: 1,
//                         ),
//                         gradient: const LinearGradient(
//                           colors: AppColors.secondaryGradient,
//                           begin: Alignment.topLeft,
//                           end: Alignment.bottomRight,
//                         ),
//                       ),
//                       child: Row(
//                         spacing: 10,
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           Icon(
//                             actionTitle!.contains('الحضور')
//                                 ? FontAwesomeIcons.qrcode
//                                 : actionTitle!.contains('الإنتقال')
//                                 ? Icons.swap_horiz_sharp
//                                 : actionTitle!.contains('رجوع')
//                                 ? Icons.chevron_left
//                                 : Icons.add,
//                             color: Colors.white,
//                           ),
//                           Text(
//                             actionTitle!,
//                             style: const TextStyle(
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                               fontSize: 16,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),

//             if (actionTitle != null &&
//                 actionTitle == 'إضافة منتج' &&
//                 AppGlobals.currentUser!.hasPermission(
//                   PermissionEnum.productsAdd.en,
//                 ))
//               Positioned(
//                 top: 10,
//                 left: 10,
//                 child: Material(
//                   color: Colors.transparent,
//                   borderRadius: BorderRadius.circular(12),
//                   child: InkWell(
//                     onTap: () {
//                       ColumnMappingSheet.show(
//                         onConfirm: (mapping, products) => context
//                             .read<ProductsCubit>()
//                             .addProductBulk(products),
//                         context: context,
//                         systemFields: {
//                           'product_name': 'اسم المنتج',
//                           'product_code': 'الكود',
//                           'product_price': 'سعر البيع',
//                           'product_cost': 'سعر الشراء',
//                           'product_quota': 'الكمية الإبتدائية',
//                           'product_category': 'القسم',
//                         },
//                       );
//                     },
//                     borderRadius: BorderRadius.circular(12),
//                     child: Ink(
//                       padding: const EdgeInsets.symmetric(
//                         horizontal: 10,
//                         vertical: 5,
//                       ),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(15),
//                         border: Border.all(
//                           color: AppColors.primary.withOpacity(0.5),
//                           width: 1,
//                         ),
//                         gradient: const LinearGradient(
//                           colors: AppColors.secondaryGradient,
//                           begin: Alignment.topLeft,
//                           end: Alignment.bottomRight,
//                         ),
//                       ),
//                       child: Row(
//                         spacing: 5,
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           Icon(
//                             FontAwesomeIcons.fileExcel,
//                             color: Colors.white,
//                             size: 16,
//                           ),
//                           Text(
//                             "نقل منتجات من Excel",
//                             textDirection: TextDirection.rtl,
//                             style: const TextStyle(
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                               fontSize: 10,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             Positioned(
//               bottom: 20,
//               right: 20,
//               left: 20,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Icon(icon, color: Colors.white, size: 40),
//                       Text(
//                         title,
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 28,
//                           fontWeight: FontWeight.bold,
//                           shadows: [
//                             Shadow(
//                               offset: Offset(2, 2),
//                               blurRadius: 4,
//                               color: Colors.black26,
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                   if (!context.isSmall) ...[
//                     const SizedBox(height: 8),
//                     Text(
//                       subtitle,
//                       maxLines: 1,
//                       overflow: TextOverflow.ellipsis,
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.9),
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
