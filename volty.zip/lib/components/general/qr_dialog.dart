// import 'dart:io';
// import 'dart:ui' as ui;
// import 'package:cashiery_mobile/components/general/my_animation.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';
// import 'package:qr_flutter/qr_flutter.dart';
// import 'package:share_plus/share_plus.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import '../../src/app_colors.dart';
// import '../../components/general/snackbar.dart';

// class QrDialog extends StatefulWidget {
//   final String qrData;
//   final String? title;
//   final String? description;
//   final Color? qrColor;
//   final Color? backgroundColor;

//   const QrDialog({
//     super.key,
//     required this.qrData,
//     this.title,
//     this.description,
//     this.qrColor,
//     this.backgroundColor,
//   });

//   @override
//   State<QrDialog> createState() => _QrDialogState();
// }

// class _QrDialogState extends State<QrDialog> {
//   final GlobalKey _qrKey = GlobalKey();
//   bool _isLoading = false;

//   Future<void> _shareQr() async {
//     setState(() => _isLoading = true);

//     try {
//       final boundary =
//           _qrKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
//       final image = await boundary.toImage(); // Reduced pixel ratio
//       final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
//       final uint8List = byteData!.buffer.asUint8List();

//       final tempDir = await getTemporaryDirectory();
//       final file = File(
//         '${tempDir.path}/qr_${DateTime.now().millisecondsSinceEpoch}.png',
//       );
//       await file.writeAsBytes(uint8List);

//       await Share.shareXFiles([
//         XFile(file.path),
//       ], text: widget.description ?? 'رمز الاستجابة السريعة');
//     } catch (e) {
//       if (mounted) {
//         MySnackBar.show(
//           context: context,
//           isAlert: true,
//           text: 'حدث خطأ أثناء المشاركة: ${e.toString()}',
//         );
//       }
//     } finally {
//       if (mounted) setState(() => _isLoading = false);
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final screenHeight = MediaQuery.of(context).size.height;

//     return Dialog(
//       backgroundColor: Colors.transparent,
//       insetPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
//       child: MyCustomAnimation(
//         duration: 750,
//         child: Container(
//           constraints: BoxConstraints(
//             maxHeight: screenHeight * 0.8,
//             maxWidth: double.infinity,
//           ),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               colors: AppColors.quintupleGradient,
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             borderRadius: BorderRadius.circular(20),
//             border: Border.all(
//               color: AppColors.primary.withOpacity(0.3),
//               width: 1,
//             ),
//             boxShadow: [
//               BoxShadow(
//                 color: AppColors.primary.withOpacity(0.2),
//                 spreadRadius: 0,
//                 blurRadius: 20,
//                 offset: const Offset(0, 10),
//               ),
//               BoxShadow(
//                 color: Colors.black.withOpacity(0.3),
//                 spreadRadius: 0,
//                 blurRadius: 40,
//                 offset: const Offset(0, 20),
//               ),
//             ],
//           ),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               _buildHeader(),
//               _buildQrSection(),
//               _buildDescription(),
//               _buildActionButtons(),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildHeader() {
//     return Container(
//       padding: EdgeInsets.all(20),
//       child: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               gradient: const LinearGradient(colors: AppColors.primaryGradient),
//               borderRadius: BorderRadius.circular(12),
//               boxShadow: [
//                 BoxShadow(
//                   color: AppColors.primary.withOpacity(0.3),
//                   spreadRadius: 0,
//                   blurRadius: 8,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Icon(FontAwesomeIcons.qrcode, color: Colors.white, size: 20),
//           ),
//           const SizedBox(width: 16),
//           Expanded(
//             child: Column(
//               textDirection: TextDirection.rtl,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   widget.title ?? 'رمز الاستجابة السريعة',
//                   style: TextStyle(
//                     fontSize: 15,
//                     fontWeight: FontWeight.bold,
//                     color: AppColors.primaryFont,
//                   ),
//                 ),
//                 if (widget.description != null) ...[
//                   const SizedBox(height: 4),
//                   Text(
//                     widget.description!,
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 12,
//                       color: AppColors.primaryFont.withOpacity(0.7),
//                     ),
//                     maxLines: 2,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                 ],
//               ],
//             ),
//           ),
//           IconButton(
//             onPressed: () => Navigator.of(context).pop(),
//             icon: Icon(
//               Icons.close,
//               color: AppColors.primaryFont.withOpacity(0.7),
//               size: 24,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildQrSection() {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 20),
//       padding: EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(
//             color: AppColors.primary.withOpacity(0.1),
//             spreadRadius: 0,
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: RepaintBoundary(
//         key: _qrKey,
//         child: Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(12),
//             color: widget.backgroundColor ?? Colors.white,
//             border: Border(
//               top: BorderSide(color: AppColors.primary, width: 3),
//               left: BorderSide(color: AppColors.primary, width: 3),
//               right: BorderSide(color: AppColors.primary, width: 10),
//               bottom: BorderSide(color: AppColors.primary, width: 10),
//             ),
//           ),
//           child: QrImageView(
//             errorCorrectionLevel: QrErrorCorrectLevel.L,
//             data: widget.qrData,
//             version: QrVersions.auto,
//             size: MediaQuery.sizeOf(context).width * 0.6,
//             backgroundColor: widget.backgroundColor ?? Colors.white,
//             foregroundColor: widget.qrColor ?? Colors.black,
//             padding: const EdgeInsets.all(8),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildDescription() {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
//       padding: EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: AppColors.orange.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Row(
//         children: [
//           Icon(Icons.info_outline, color: AppColors.orange, size: 20),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(
//               'امسح رمز QR للحضور / الإنصراف السريع',
//               style: TextStyle(
//                 color: AppColors.orange,
//                 fontSize: 12,
//                 fontWeight: FontWeight.w600,
//               ),
//               textDirection: TextDirection.rtl,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildActionButtons() {
//     return Container(
//       padding: EdgeInsets.all(20),
//       child: Column(
//         children: [
//           // Main action buttons
//           Row(
//             children: [
//               Expanded(
//                 child: _buildActionButton(
//                   onPressed: _isLoading ? null : _shareQr,
//                   icon: FontAwesomeIcons.download,
//                   label: 'مشاركة',
//                   isPrimary: false,
//                   isOutlined: true,
//                 ),
//               ),
//             ],
//           ),

//           // Loading indicator
//         ],
//       ),
//     );
//   }

//   Widget _buildActionButton({
//     required VoidCallback? onPressed,
//     required IconData icon,
//     required String label,
//     required bool isPrimary,
//     bool isOutlined = false,
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: isPrimary && !isOutlined
//             ? const LinearGradient(colors: AppColors.primaryGradient)
//             : null,
//         borderRadius: BorderRadius.circular(12),
//         border: isOutlined
//             ? Border.all(color: AppColors.primary.withOpacity(0.5), width: 1)
//             : null,
//         boxShadow: isPrimary && !isOutlined
//             ? [
//                 BoxShadow(
//                   color: AppColors.primary.withOpacity(0.3),
//                   spreadRadius: 0,
//                   blurRadius: 8,
//                   offset: const Offset(0, 2),
//                 ),
//               ]
//             : null,
//       ),
//       child: ElevatedButton.icon(
//         onPressed: onPressed,
//         icon: Icon(
//           icon,
//           color: isPrimary && !isOutlined ? Colors.white : AppColors.primary,
//           size: 16,
//         ),
//         label: Text(
//           label,
//           style: TextStyle(
//             color: isPrimary && !isOutlined ? Colors.white : AppColors.primary,
//             fontSize: 14,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         style: ElevatedButton.styleFrom(
//           backgroundColor: isPrimary && !isOutlined
//               ? Colors.transparent
//               : isOutlined
//               ? Colors.transparent
//               : AppColors.secondary,
//           shadowColor: Colors.transparent,
//           padding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(12),
//           ),
//         ),
//       ),
//     );
//   }
// }

// // Helper function to show the QR dialog
// class QrDialogHelper {
//   static Future<void> show({
//     required BuildContext context,
//     required String qrData,
//     String? title,
//     String? description,
//     Color? qrColor,
//     Color? backgroundColor,
//   }) {
//     return showDialog<void>(
//       context: context,
//       barrierDismissible: true,
//       barrierColor: Colors.black.withOpacity(0.7),
//       builder: (BuildContext context) {
//         return QrDialog(
//           qrData: qrData,
//           title: title,
//           description: description,
//           qrColor: qrColor,
//           backgroundColor: backgroundColor,
//         );
//       },
//     );
//   }
// }
