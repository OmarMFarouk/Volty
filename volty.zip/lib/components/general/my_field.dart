import '../../src/app_responsive.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../src/app_colors.dart';

class MyField extends StatefulWidget {
  const MyField({
    super.key,
    required this.hint,
    required this.icon,
    this.isEnabled,
    this.validator,
    this.formatters,
    this.isObscure,
    this.controller,
    this.animationDuration,
    this.onChanged,
    this.onTap,
    this.keyType,
    this.hasBorder = true,
    this.canBeEmpty,
    this.maxLength,
    this.clearable,
    this.suffixIcon,
    this.maxWidth,
  });

  final bool? isEnabled;
  final bool? isObscure;
  final List<TextInputFormatter>? formatters;
  final String hint;
  final IconData icon;
  final double? maxWidth;
  final Widget? suffixIcon;
  final String? Function(String?)? validator;
  final int? animationDuration;
  final TextEditingController? controller;
  final Function(String)? onChanged;
  final VoidCallback? onTap;
  final int? maxLength;
  final TextInputType? keyType;
  final bool? hasBorder, canBeEmpty, clearable;

  @override
  State<MyField> createState() => _MyFieldState();
}

class _MyFieldState extends State<MyField> {
  @override
  void initState() {
    super.initState();

    widget.controller?.addListener(_refresh);
  }

  void _refresh() => mounted ? setState(() {}) : null;

  @override
  void dispose() {
    widget.controller?.removeListener(_refresh);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<Offset>(
      curve: Curves.fastLinearToSlowEaseIn,
      tween: Tween<Offset>(begin: const Offset(0, 300), end: Offset.zero),
      duration: const Duration(milliseconds: 0),
      builder: (context, value, child) {
        return Transform.translate(offset: value, child: child);
      },
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: InkWell(
          onTap: widget.onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            constraints: widget.maxWidth != null
                ? BoxConstraints(maxWidth: widget.maxWidth!)
                : null,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: AppColors.primaryGradient,
              ),
              borderRadius: BorderRadius.circular(15),
              border: widget.hasBorder!
                  ? Border.all(
                      color: AppColors.primary.withOpacity(0.5),
                      width: 1,
                    )
                  : null,
              boxShadow: widget.controller?.text.isEmpty ?? false
                  ? null
                  : [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.5),
                        spreadRadius: 0,
                        blurRadius: 20,
                        offset: const Offset(0, 5),
                      ),
                    ],
            ),
            child: TextFormField(
              textInputAction: TextInputAction.next,
              autofocus: false,
              keyboardType: widget.keyType,
              cursorColor: AppColors.primary,
              maxLength: widget.maxLength ?? 11,
              buildCounter:
                  (
                    _, {
                    required currentLength,
                    required isFocused,
                    required maxLength,
                  }) => null,
              onChanged: widget.onChanged,
              obscureText: widget.isObscure ?? false,
              enabled: widget.isEnabled,
              inputFormatters:
                  widget.formatters ?? [FilteringTextInputFormatter.deny(' ')],
              validator: (value) {
                if (value!.isEmpty && widget.canBeEmpty == null) {
                  return '*فارغ';
                }
                if (widget.validator != null) {
                  return widget.validator!(value);
                }
                return null;
              },
              style: TextStyle(
                color:
                    widget.isEnabled == null ||
                        (widget.isEnabled != null && widget.icon != Icons.email)
                    ? AppColors.primary
                    : AppColors.secondary,
                fontSize: 14,
              ),
              controller: widget.controller,
              decoration: InputDecoration(
                errorStyle: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: AppColors.red,
                  letterSpacing: context.isSmall ? 1 : 2,
                  fontSize: context.isSmall ? 10 : 13,
                ),
                disabledBorder: InputBorder.none,
                label: Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.hint,
                        style: TextStyle(
                          color: Colors.grey[400]!.withOpacity(0.7),
                          fontWeight: FontWeight.bold,
                          fontSize: widget.hint.contains("المدفوع") ? 11 : 14,
                        ),
                      ),
                    ),
                  ],
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(color: AppColors.primary, width: 2),
                ),
                prefixIcon: Icon(widget.icon, color: AppColors.primary),
                suffixIcon:
                    widget.suffixIcon ??
                    ((widget.clearable != null &&
                            widget.controller != null &&
                            widget.controller!.text.isNotEmpty)
                        ? IconButton(
                            onPressed: () {
                              FocusManager.instance.primaryFocus!.unfocus();
                              widget.controller!.clear();
                              if (widget.onChanged != null) {
                                widget.onChanged!(widget.controller!.text);
                              }
                            },
                            icon: Icon(Icons.clear),
                            color: AppColors.primaryFont.withAlpha(120),
                          )
                        : null),

                border: InputBorder.none,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
