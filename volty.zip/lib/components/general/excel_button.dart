// import 'package:cashiery_mobile/components/general/my_loading_indicator.dart';
// import 'package:cashiery_mobile/components/general/snackbar.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// import '../../src/app_colors.dart';

// class ExcelButton extends StatelessWidget {
//   const ExcelButton({
//     super.key,
//     required this.onExport,
//     this.switchColor = false,
//     required this.isEmpty,
//     this.title,
//     this.icon,
//   });
//   final bool isEmpty;
//   final bool switchColor;
//   final Future Function() onExport;
//   final String? title;
//   final IconData? icon;

//   @override
//   Widget build(BuildContext context) {
//     return Tooltip(
//       message: "..لا يوجد بيانات",
//       triggerMode: TooltipTriggerMode.tap,
//       exitDuration: isEmpty ? Duration.zero : null,
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(8),
//           onTap: isEmpty
//               ? null
//               : () async {
//                   if (title == null) MyLoadingIndicator.showLoader(context);

//                   await onExport().timeout(Duration(seconds: 10));
//                   if (title == null) {
//                     await Future.delayed(Duration(seconds: 1), () {
//                       Navigator.pop(context);

//                       MySnackBar.show(
//                         context: context,
//                         isAlert: false,
//                         text: 'تم التصدير الى ملفات الهاتف بنجاح',
//                       );
//                     });
//                   }
//                 },
//           child: Ink(
//             padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//             decoration: BoxDecoration(
//               gradient: isEmpty
//                   ? null
//                   : LinearGradient(
//                       colors: switchColor
//                           ? AppColors.secondaryGradient
//                           : AppColors.primaryGradient,
//                     ),
//               color: isEmpty ? AppColors.grey : null,
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: Row(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Icon(
//                   icon ?? FontAwesomeIcons.fileExcel,
//                   size: title == null ? 16 : 14,
//                   color: Colors.white,
//                 ),
//                 SizedBox(width: 6),
//                 Text(
//                   title ?? 'تصدير',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                     fontSize: title == null ? 13 : 11,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// class InfoButton extends StatelessWidget {
//   const InfoButton({super.key, required this.onTap});
//   final VoidCallback onTap;

//   @override
//   Widget build(BuildContext context) {
//     return Material(
//       color: Colors.transparent,
//       child: InkWell(
//         borderRadius: BorderRadius.circular(8),
//         onTap: onTap,
//         child: Ink(
//           padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(colors: AppColors.primaryGradient),
//             borderRadius: BorderRadius.circular(8),
//           ),
//           child: Row(
//             mainAxisSize: MainAxisSize.min,
//             children: const [
//               Icon(FontAwesomeIcons.circleInfo, size: 16, color: Colors.white),
//               SizedBox(width: 6),
//               Text(
//                 'تفاصيل',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 13,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
