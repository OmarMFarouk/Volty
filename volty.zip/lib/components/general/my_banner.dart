// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:marquee/marquee.dart';

// import '../../src/app_colors.dart';
// import '../../src/app_globals.dart';

// class MyBanner extends StatefulWidget {
//   const MyBanner({super.key, required this.onTap});
//   final VoidCallback onTap;

//   @override
//   State<MyBanner> createState() => _MyBannerState();
// }

// class _MyBannerState extends State<MyBanner> with TickerProviderStateMixin {
//   late AnimationController _backgroundController;
//   late AnimationController _iconController;
//   late Animation<Color?> _colorAnimation;
//   late Animation<double> _iconRotation;

//   @override
//   void initState() {
//     super.initState();

//     _backgroundController = AnimationController(
//       duration: const Duration(milliseconds: 3000),
//       vsync: this,
//     );

//     _iconController = AnimationController(
//       duration: const Duration(milliseconds: 1500),
//       vsync: this,
//     );

//     _colorAnimation =
//         ColorTween(
//           begin: AppColors.primary,
//           end: AppColors.primary.withOpacity(0.7),
//         ).animate(
//           CurvedAnimation(
//             parent: _backgroundController,
//             curve: Curves.easeInOut,
//           ),
//         );

//     _iconRotation = Tween<double>(begin: 0, end: 0.1).animate(
//       CurvedAnimation(parent: _iconController, curve: Curves.elasticOut),
//     );

//     _backgroundController.repeat(reverse: true);
//     _iconController.repeat(reverse: true);
//   }

//   @override
//   void dispose() {
//     _backgroundController.stop();
//     _iconController.stop();
//     _backgroundController.dispose();
//     _iconController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: Listenable.merge([_backgroundController, _iconController]),
//       builder: (context, child) {
//         return Container(
//           height: 52,
//           width: double.infinity,
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [
//                 _colorAnimation.value ?? AppColors.primary,
//                 AppColors.primary,
//                 _colorAnimation.value ?? AppColors.primary,
//               ],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             boxShadow: [
//               BoxShadow(
//                 color: AppColors.primary.withOpacity(0.3),
//                 spreadRadius: 0,
//                 blurRadius: 12,
//                 offset: const Offset(0, 3),
//               ),
//             ],
//           ),
//           child: Material(
//             color: Colors.transparent,
//             child: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//               child: Row(
//                 spacing: 12,
//                 children: [
//                   Transform.rotate(
//                     angle: _iconRotation.value,
//                     child: Container(
//                       padding: const EdgeInsets.all(6),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.2),
//                         shape: BoxShape.circle,
//                         border: Border.all(
//                           color: Colors.white.withOpacity(0.4),
//                           width: 1.5,
//                         ),
//                       ),
//                       child: Icon(
//                         FontAwesomeIcons.bullhorn,
//                         color: Colors.white,
//                         size: 14,
//                       ),
//                     ),
//                   ),
//                   Expanded(
//                     child: Directionality(
//                       textDirection: TextDirection.rtl,
//                       child: SizedBox(
//                         height: kToolbarHeight * 0.32,
//                         child: Marquee(
//                           text: AppGlobals.appConfigs?.announcement ?? '',
//                           style: const TextStyle(
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                             fontSize: 12,
//                             letterSpacing: 0.3,
//                             shadows: [
//                               Shadow(
//                                 color: Colors.black45,
//                                 offset: Offset(0, 1),
//                                 blurRadius: 3,
//                               ),
//                             ],
//                           ),
//                           scrollAxis: Axis.horizontal,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           blankSpace: 50.0,
//                           velocity: 50.0,
//                           pauseAfterRound: Duration(seconds: 0),
//                           startPadding: 10.0,
//                           fadingEdgeEndFraction: 0.2,
//                           fadingEdgeStartFraction: 0.2,
//                         ),
//                       ),
//                     ),
//                   ),
//                   if (AppGlobals.appConfigs!.isdismissable!)
//                     InkWell(
//                       onTap: widget.onTap,
//                       borderRadius: BorderRadius.circular(6),
//                       child: Container(
//                         padding: const EdgeInsets.all(6),
//                         decoration: BoxDecoration(
//                           color: Colors.white.withOpacity(0.15),
//                           borderRadius: BorderRadius.circular(6),
//                         ),
//                         child: Icon(
//                           FontAwesomeIcons.times,
//                           color: Colors.white,
//                           size: 12,
//                         ),
//                       ),
//                     ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
