// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:cashiery_mobile/src/app_colors.dart';

// class ImageDialog {
//   static void show(context, image) {
//     showDialog(
//       context: context,
//       builder: (_) => Dialog(
//         backgroundColor: Colors.transparent,
//         insetPadding: const EdgeInsets.all(10),
//         child: Stack(
//           alignment: Alignment.topRight,
//           children: [
//             GestureDetector(
//               onTap: () => Navigator.pop(context),
//               child: Container(
//                 width: 400,
//                 color: Colors.black.withOpacity(0.85),
//                 child: ClipRRect(
//                   borderRadius: BorderRadius.circular(12),
//                   child: image == null || image.isEmpty
//                       ? Padding(
//                           padding: EdgeInsets.all(8.0),
//                           child: Icon(
//                             Icons.error,
//                             color: AppColors.primary,
//                             size: 40,
//                           ),
//                         )
//                       : InteractiveViewer(
//                           child: CachedNetworkImage(
//                             imageUrl: image,
//                             fit: BoxFit.contain,

//                             errorWidget: (_, __, ___) => const Padding(
//                               padding: EdgeInsets.all(8.0),
//                               child: Icon(
//                                 Icons.error,
//                                 color: AppColors.primary,
//                                 size: 40,
//                               ),
//                             ),
//                           ),
//                         ),
//                 ),
//               ),
//             ),
//             IconButton(
//               style: ButtonStyle(
//                 backgroundColor: WidgetStatePropertyAll(Colors.white10),
//               ),
//               icon: const Icon(Icons.close, color: Colors.white),
//               onPressed: () => Navigator.pop(context),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
