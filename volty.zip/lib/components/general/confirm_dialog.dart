// import 'package:cashiery_mobile/src/app_colors.dart';
// import 'package:cashiery_mobile/src/app_globals.dart';
// import 'package:flutter/material.dart';

// String? paymentValidation({
//   required String? value,
//   required String field,
//   required TextEditingController cashCtrl,
//   required TextEditingController bankCtrl,
//   required double total,
//   bool? strict,
// }) {
//   final entered = double.tryParse(value ?? '') ?? 0;
//   final cash = field == 'cash' ? entered : double.tryParse(cashCtrl.text) ?? 0;
//   final bank = field == 'bank' ? entered : double.tryParse(bankCtrl.text) ?? 0;
//   final combined = cash + bank;

//   if (entered < 0) return 'لا يمكن إدخال قيمة سالبة';
//   if (combined == 0 && strict != null) {
//     return 'أدخل مبلغاً في حقل واحد على الأقل';
//   }
//   if (combined > total && strict != null) {
//     return 'إجمالي الدفع أكبر من السعر المستحق';
//   }

//   return null;
// }

// Future<bool?> showConfirmPaymentDialog(
//   BuildContext context,
//   double totalPaid, {
//   String? operationType,
// }) {
//   FocusManager.instance.primaryFocus?.unfocus();
//   return showDialog<bool>(
//     context: context,
//     barrierDismissible: false,
//     builder: (context) => AlertDialog(
//       backgroundColor: AppColors.secondaryGradient.first,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       contentPadding: const EdgeInsets.all(24),
//       title: Row(
//         spacing: 12,
//         mainAxisAlignment: MainAxisAlignment.end,
//         children: [
//           Text(
//             'تأكيد ${"ال${operationType ?? "دفع"}"}',
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//               fontSize: 16,
//               color: AppColors.primary,
//             ),
//           ),
//           Container(
//             padding: const EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               color: AppColors.green.withOpacity(0.3),
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: Icon(
//               Icons.check_circle_outline,
//               color: Colors.green.shade600,
//               size: 24,
//             ),
//           ),
//         ],
//       ),
//       content: Column(
//         mainAxisSize: MainAxisSize.min,
//         crossAxisAlignment: CrossAxisAlignment.end,
//         children: [
//           Text(
//             '.سيتم ${operationType ?? "دفع"} مبلغ ${totalPaid.toStringAsFixed(2)} ${AppGlobals.currentGym!.currency}',
//             style: const TextStyle(fontSize: 16, color: AppColors.primaryFont),
//           ),
//           const SizedBox(height: 8),
//           const Text(
//             'هل أنت متأكد من إتمام هذه العملية؟',
//             style: TextStyle(fontSize: 14, color: Colors.grey),
//           ),
//         ],
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(context, false),
//           child: Text(
//             'إلغاء',
//             style: TextStyle(
//               color: Colors.grey.shade500,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         ElevatedButton(
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.green.shade600,
//             foregroundColor: Colors.white,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(8),
//             ),
//             padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
//           ),
//           onPressed: () => Navigator.pop(context, true),
//           child: const Text(
//             'تأكيد',
//             style: TextStyle(fontWeight: FontWeight.bold),
//           ),
//         ),
//       ],
//     ),
//   );
// }
