import 'package:flutter/material.dart';

class DateRangeDialog extends StatelessWidget {
  const DateRangeDialog({super.key, required this.onConfirm});
  final Function(DateTimeRange<DateTime> p0) onConfirm;
  void show(context) =>
      showDialog<DateTimeRange>(context: context, builder: build).then((
        DateTimeRange<DateTime>? e,
      ) {
        if (e != null) {
          onConfirm(e);
        }
      });
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        contentPadding: EdgeInsets.zero,
        content: SizedBox(
          width: MediaQuery.sizeOf(context).width * 0.25,
          height: MediaQuery.sizeOf(context).height * 0.7,
          child: DateRangePickerDialog(
            confirmText: 'تأكيد',
            cancelText: 'إلغاء',
            saveText: 'حفظ',
            fieldStartLabelText: 'تاريخ البداية',
            fieldEndLabelText: 'تاريخ النهاية',
            helpText: 'إختار التاريخ',
            firstDate: DateTime(2020),
            currentDate: DateTime.now(),
            initialDateRange: DateTimeRange(
              start: DateTime.now().subtract(const Duration(days: 7)),
              end: DateTime.now(),
            ),
            lastDate: DateTime.now().add(const Duration(days: 30)),
          ),
        ),
      ),
    );
  }
}
