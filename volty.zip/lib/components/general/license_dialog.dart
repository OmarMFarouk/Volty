// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';

// import '../../src/app_shared.dart';
// import '../general/snackbar.dart';

// class LicenseDialog extends StatelessWidget {
//   const LicenseDialog({super.key, required this.onConfirm});
//   final VoidCallback onConfirm;
//   @override
//   Widget build(BuildContext context) {
//     String pinCode = '';
//     return AlertDialog(
//       title: const Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [Text('تـأكـيد التعديلات')],
//       ),
//       content: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           TextField(
//             inputFormatters: [FilteringTextInputFormatter.deny(' ')],
//             obscureText: true,
//             onChanged: (value) => pinCode = value,
//             textDirection: TextDirection.rtl,
//             decoration: const InputDecoration(
//               label: Row(children: [Spacer(), Text('رقم رترخيص البرنامج')]),
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.all(Radius.circular(10)),
//               ),
//             ),
//           ),
//           const SizedBox(height: 10),
//         ],
//       ),
//       actions: <Widget>[
//         TextButton(
//           child: const Text('تأكيد'),
//           onPressed: () async {
//             Navigator.of(context).pop();
//             if (AppShared.readString('pin') == pinCode) {
//               onConfirm();
//             } else {
//               MySnackBar.show(
//                 context: context,
//                 isAlert: true,
//                 text: 'رقم الترخيص خاطئ',
//               );
//             }
//           },
//         ),
//         TextButton(
//           child: const Text('إلغاء'),
//           onPressed: () {
//             Navigator.of(context).pop();
//           },
//         ),
//       ],
//     );
//   }

//   showLicenseDialog(context) => showDialog(context: context, builder: build);
// }
