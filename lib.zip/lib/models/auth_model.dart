class Household {
  String? householdid;
  String? householdname;
  String? householdaddress;
  String? householdownerId;
  String? householddateCreated;

  Household({
    this.householdid,
    this.householdname,
    this.householdaddress,
    this.householdownerId,
    this.householddateCreated,
  });

  Household.fromJson(Map<String, dynamic> json) {
    householdid = json['household_id'];
    householdname = json['household_name'];
    householdaddress = json['household_address'];
    householdownerId = json['household_ownerId'];
    householddateCreated = json['household_dateCreated'];
  }
}

class AuthModel {
  bool? success;
  String? message;
  User? user;
  Household? household;

  AuthModel({this.success, this.message, this.user, this.household});

  AuthModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    user = json['user'] != null ? User?.fromJson(json['user']) : null;
    household = json['household'] != null
        ? Household?.fromJson(json['household'])
        : null;
  }
}

class User {
  String? userId;
  String? householdId;
  String? name;
  String? email;
  String? phone;
  String? password;
  String? fcmToken;
  String? userimage;
  String? lastAccess;
  String? dateCreated;
  String? dateModified;

  User({
    this.userId,
    this.householdId,
    this.name,
    this.email,
    this.phone,
    this.password,
    this.fcmToken,
    this.userimage,
    this.lastAccess,
    this.dateCreated,
    this.dateModified,
  });
  loginJson() => {"user_email": email, "user_password": password};
  createJson({required String houseAddress, required String houseName}) => {
    "user_name": name,
    "user_email": email,
    "user_password": password,
    "user_phone": phone,
    "user_fcmToken": "device error",
    "household_name": houseName,
    "household_address": houseAddress,
  };
  User.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    householdId = json['user_hid'];
    name = json['user_name'];
    email = json['user_email'];
    phone = json['user_phone'];
    password = json['user_password'];
    fcmToken = json['user_fcmToken'];
    userimage = json['user_image'] ?? "";
    lastAccess = json['user_lastAccess'];
    dateCreated = json['user_dateCreated'];
    dateModified = json['user_dateModified'];
  }
}
