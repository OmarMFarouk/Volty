import 'package:flutter/material.dart';

class DeviceModel {
  final String name;
  final IconData icon;
  final double power;
  final bool isOn;
  final int usage;

  DeviceModel(this.name, this.icon, this.power, this.isOn, this.usage);
}
