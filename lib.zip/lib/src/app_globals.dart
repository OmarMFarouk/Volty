import 'package:volty/models/auth_model.dart';

class AppGlobals {
  static User? currentUser;
  static Household? currentHouse;

  static bool isModelsInitialized() {
    return currentHouse != null && currentUser != null;
  }
}
