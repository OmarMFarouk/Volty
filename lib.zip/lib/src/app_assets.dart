class AppAssets {
  static const String logo = 'assets/images/logo.png';
}
