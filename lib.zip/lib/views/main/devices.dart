import 'package:flutter/material.dart';

import '../../models/device_model.dart';

class DevicesScreen extends StatefulWidget {
  const DevicesScreen({super.key});

  @override
  State<DevicesScreen> createState() => _DevicesScreenState();
}

class _DevicesScreenState extends State<DevicesScreen> {
  bool _showAIInsights = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'الأجهزة',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'إدارة جميع الأجهزة الذكية',
                style: TextStyle(color: Colors.grey[400], fontSize: 15),
              ),
              const SizedBox(height: 25),
              if (_showAIInsights) ...[
                _buildAIInsightBanner(),
                const SizedBox(height: 20),
              ],
              _buildRoomSection('غرفة المعيشة', [
                DeviceModel(
                  'مكيف الهواء',
                  Icons.ac_unit_rounded,
                  2.4,
                  true,
                  72,
                ),
                DeviceModel('التلفاز الذكي', Icons.tv_rounded, 0.15, true, 45),
                DeviceModel('الإضاءة', Icons.lightbulb_rounded, 0.08, true, 25),
              ]),
              const SizedBox(height: 20),
              _buildRoomSection('غرفة النوم', [
                DeviceModel(
                  'مكيف الهواء',
                  Icons.ac_unit_rounded,
                  2.2,
                  false,
                  0,
                ),
                DeviceModel(
                  'مصباح السرير',
                  Icons.lightbulb_outline_rounded,
                  0.05,
                  true,
                  15,
                ),
              ]),
              const SizedBox(height: 20),
              _buildRoomSection('المطبخ', [
                DeviceModel('الثلاجة', Icons.kitchen_rounded, 0.35, true, 88),
                DeviceModel(
                  'غسالة الأطباق',
                  Icons.countertops_rounded,
                  1.5,
                  false,
                  0,
                ),
                DeviceModel(
                  'الميكروويف',
                  Icons.microwave_rounded,
                  1.2,
                  false,
                  0,
                ),
              ]),
              const SizedBox(height: 20),
              _buildRoomSection('الحمام', [
                DeviceModel(
                  'سخان الماء',
                  Icons.water_drop_rounded,
                  1.8,
                  true,
                  68,
                ),
              ]),
              SizedBox(height: kToolbarHeight * 1.5),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAIInsightBanner() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF6C63FF).withOpacity(0.2),
            const Color(0xFF5B54E8).withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF6C63FF).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF6C63FF).withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.psychology_rounded,
              color: const Color(0xFF6C63FF),
              size: 28,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'رؤية ذكية',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'مكيف غرفة المعيشة يستهلك 72% - يُنصح بخفض درجة الحرارة',
                  style: TextStyle(color: Colors.grey[300], fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                _showAIInsights = false;
              });
            },
            icon: Icon(Icons.close, color: Colors.grey[400], size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildRoomSection(String room, List<DeviceModel> devices) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF1E2538),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2D3548)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.room_rounded,
                color: const Color(0xFFB8FF57),
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                room,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFFB8FF57).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${devices.where((d) => d.isOn).length}/${devices.length}',
                  style: TextStyle(
                    color: const Color(0xFFB8FF57),
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ...devices.map(
          (device) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildDeviceCard(device),
          ),
        ),
      ],
    );
  }

  Widget _buildDeviceCard(DeviceModel device) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1E2538),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: device.isOn
              ? const Color(0xFFB8FF57).withOpacity(0.3)
              : const Color(0xFF2D3548),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: device.isOn
                      ? const Color(0xFFB8FF57).withOpacity(0.15)
                      : const Color(0xFF2D3548),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(
                  device.icon,
                  color: device.isOn ? const Color(0xFFB8FF57) : Colors.grey,
                  size: 28,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      device.name,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.bolt, color: Colors.grey[400], size: 14),
                        const SizedBox(width: 4),
                        Text(
                          '${device.power} ك.و',
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 13,
                          ),
                        ),
                        if (device.isOn) ...[
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: _getUsageColor(
                                device.usage,
                              ).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '${device.usage}%',
                              style: TextStyle(
                                color: _getUsageColor(device.usage),
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              Switch(
                value: device.isOn,
                onChanged: (value) {},
                activeColor: const Color(0xFFB8FF57),
                activeTrackColor: const Color(0xFFB8FF57).withOpacity(0.3),
              ),
            ],
          ),
          if (device.isOn) ...[
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.schedule, size: 18),
                    label: Text('جدولة'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.grey[300],
                      backgroundColor: const Color(0xFF2D3548),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.settings, size: 18),
                    label: Text('إعدادات'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.grey[300],
                      backgroundColor: const Color(0xFF2D3548),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Color _getUsageColor(int usage) {
    if (usage >= 80) return const Color(0xFFFF6B6B);
    if (usage >= 50) return const Color(0xFFFFB84D);
    return const Color(0xFF4ECDC4);
  }
}
