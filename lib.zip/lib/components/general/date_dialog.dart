import 'package:flutter/material.dart';

class DateDialog extends StatelessWidget {
  const DateDialog({super.key, required this.onConfirm, this.onClear});
  final Function(DateTime p0) onConfirm;
  final VoidCallback? onClear;
  void show(context) => showDialog<DateTime>(context: context, builder: build)
      .then((DateTime? e) {
        if (e == null && onClear != null) {
          onClear!();
        }
        if (e != null) {
          onConfirm(e);
        }
      });
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        contentPadding: EdgeInsets.zero,
        content: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.5,
          child: DatePickerDialog(
            confirmText: 'تأكيد',
            cancelText: 'إلغاء',
            fieldLabelText: "ادخل التاريخ",
            helpText: 'إختار التاريخ',
            firstDate: DateTime(2000),
            currentDate: DateTime.now(),

            initialDate: DateTime.now(),

            lastDate: DateTime.now().add(const Duration(days: 30)),
          ),
        ),
      ),
    );
  }
}
