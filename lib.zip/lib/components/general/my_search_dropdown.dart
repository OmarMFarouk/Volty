// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:simple_search_dropdown/simple_search_dropdown.dart';

// import '../../blocs/cashier_bloc/cashier_cubit.dart';
// import '../../blocs/clients_bloc/clients_cubit.dart';
// import '../../blocs/clients_bloc/clients_states.dart';
// import '../../blocs/inventory_bloc/inventory_cubit.dart';
// import '../../models/clients_model.dart';
// import '../../src/app_colors.dart';

// class MyDropDownSearch extends StatelessWidget {
//   const MyDropDownSearch({super.key, this.onChange});
//   final VoidCallback? onChange;
//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<ClientsCubit, ClientsStates>(
//       builder: (context, state) {
//         var cubit = context.read<ClientsCubit>();
//         List<ValueItem<Client>> suggestions =
//             cubit.clientsModel?.clients
//                 ?.map(
//                   (e) => ValueItem<Client>(
//                     value: e!,
//                     label: '${e.name} || ${e.phone}',
//                   ),
//                 )
//                 .toList() ??
//             [];

//         return Directionality(
//           textDirection: TextDirection.rtl,
//           child: SearchDropDown(
//             selectedItem: selectedClientLabel == null
//                 ? null
//                 : ValueItem(label: selectedClientLabel!),
//             listItems: suggestions,
//             onClear: () {
//               context.read<ClientsCubit>().selectedClient = null;
//               context.read<InventoryCubit>().selectedClient = null;
//               context.read<CashierCubit>().selectedClient = null;
//             },
//             updateSelectedItem: (s) {
//               if (s != null) {
//                 context.read<ClientsCubit>().selectedClient = s.value;
//                 context.read<InventoryCubit>().selectedClient = s.value;
//                 context.read<CashierCubit>().selectedClient = s.value;
//                 selectedClientLabel = s.label;
//                 if (onChange != null) {
//                   onChange!();
//                 }
//               }
//             },
//             addMode: false,
//             editMode: false,
//             deleteMode: false,
//             searchBarSettings: SimpleSearchbarSettings(
//               hint: selectedClientLabel ?? 'حدد عميل..',
//               backgroundColor: AppColors.primary,
//               showClearIcon: false,
//               hintStyle: TextStyle(color: AppColors.primaryFont),
//             ),
//             overlayListSettings: const SimpleOverlaySettings(
//               selectedItemBackgroundColor: Colors.cyan,
//             ),
//             searchController: SearchController(),
//           ),
//         );
//       },
//     );
//   }
// }
