// import 'package:flutter/material.dart';
// import 'package:cashiery_mobile/src/app_colors.dart';

// class MyFilterChip extends StatelessWidget {
//   const MyFilterChip({
//     super.key,
//     required this.label,
//     required this.current,
//     required this.count,
//     required this.icon,
//     required this.onTap,
//   });
//   final String label, current;
//   final int count;
//   final IconData icon;
//   final Function(String) onTap;
//   @override
//   Widget build(BuildContext context) {
//     bool isSelected = label == current;
//     return GestureDetector(
//       onTap: () {
//         onTap(label);
//         Scrollable.ensureVisible(
//           context,
//           curve: Curves.fastLinearToSlowEaseIn,
//           alignment: 0.5,
//           duration: Duration(milliseconds: 500),
//         );
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
//         decoration: BoxDecoration(
//           gradient: isSelected
//               ? LinearGradient(colors: AppColors.tertiaryGradient)
//               : const LinearGradient(
//                   colors: [Color(0xFF3A3A3A), Color(0xFF4A4A4A)],
//                 ),
//           borderRadius: BorderRadius.circular(25),
//           boxShadow: isSelected
//               ? [
//                   BoxShadow(
//                     color: AppColors.primary.withOpacity(0.4),
//                     spreadRadius: 0,
//                     blurRadius: 10,
//                     offset: const Offset(0, 3),
//                   ),
//                 ]
//               : null,
//         ),
//         child: Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Icon(icon, color: Colors.white, size: 16),
//             const SizedBox(width: 8),
//             Text(
//               label,
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//                 fontSize: 12,
//               ),
//             ),
//             const SizedBox(width: 8),
//             Container(
//               padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//               decoration: BoxDecoration(
//                 color: Colors.white.withOpacity(0.2),
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: Text(
//                 count.toString(),
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 11,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
