// import 'package:flutter/material.dart';
// import 'package:cashiery_mobile/components/general/my_field.dart';
// import 'package:image_picker/image_picker.dart';

// import '../../src/app_colors.dart';

// // Add Client Sheet
// void showImageSourceDialog(
//   context,
//   XFile? pickedImage, {
//   required Future<void> Function() onCamera,
//   required Future<void> Function() onGallery,
//   required Future<void> Function() onDelete,
// }) {
//   FocusManager.instance.primaryFocus?.unfocus();

//   showDialog(
//     context: context,
//     builder: (context) => Dialog(
//       child: Container(
//         decoration: BoxDecoration(
//           gradient: const LinearGradient(
//             colors: [Color(0xFF1A1A1A), Color(0xFF2A2A2A)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//           borderRadius: const BorderRadius.only(
//             topLeft: Radius.circular(30),
//             topRight: Radius.circular(30),
//           ),
//           boxShadow: [
//             BoxShadow(
//               color: AppColors.primary.withOpacity(0.3),
//               spreadRadius: 0,
//               blurRadius: 20,
//               offset: const Offset(0, -5),
//             ),
//           ],
//         ),
//         child: SingleChildScrollView(
//           child: Column(
//             children: [
//               // Header
//               Container(
//                 padding: const EdgeInsets.all(20),
//                 decoration: const BoxDecoration(
//                   gradient: LinearGradient(colors: AppColors.primaryGradient),
//                   borderRadius: BorderRadius.only(
//                     topLeft: Radius.circular(30),
//                     topRight: Radius.circular(30),
//                   ),
//                 ),
//                 child: Column(
//                   children: [
//                     Container(
//                       width: 40,
//                       height: 4,
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.5),
//                         borderRadius: BorderRadius.circular(2),
//                       ),
//                     ),

//                     Row(
//                       children: [
//                         GestureDetector(
//                           onTap: () => Navigator.pop(context),
//                           child: Container(
//                             padding: const EdgeInsets.all(8),
//                             decoration: BoxDecoration(
//                               color: Colors.white.withOpacity(0.2),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(
//                               Icons.close,
//                               color: Colors.white,
//                               size: 20,
//                             ),
//                           ),
//                         ),
//                         Expanded(
//                           child: Text(
//                             '🖼️ إختيار مصدر الصورة',
//                             textAlign: TextAlign.center,
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 20,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                         const SizedBox(width: 36),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),

//               // Form Content
//               Padding(
//                 padding: const EdgeInsets.all(20),
//                 child: Column(
//                   spacing: 16,
//                   crossAxisAlignment: CrossAxisAlignment.end,
//                   children: [
//                     Row(
//                       spacing: 12,
//                       children: [
//                         Expanded(
//                           child: MyField(
//                             onTap: () => onGallery().whenComplete(
//                               () => Navigator.pop(context),
//                             ),
//                             hint: 'المعرض',
//                             icon: Icons.image,
//                             isEnabled: false,
//                           ),
//                         ),
//                         Expanded(
//                           child: MyField(
//                             onTap: () => onCamera().whenComplete(
//                               () => Navigator.pop(context),
//                             ),
//                             isEnabled: false,
//                             hint: 'الكاميرا',
//                             icon: Icons.camera_alt,
//                           ),
//                         ),
//                       ],
//                     ),
//                     if (pickedImage != null)
//                       MyField(
//                         onTap: () {
//                           onDelete();
//                           Navigator.pop(context);
//                         },
//                         isEnabled: false,
//                         hint: 'إزالة الصورة',
//                         icon: Icons.image_not_supported_sharp,
//                       ),
//                   ],
//                 ),
//               ),

//               // Action Buttons
//               Container(
//                 padding: const EdgeInsets.all(20),
//                 decoration: const BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
//                   ),
//                   borderRadius: BorderRadius.only(
//                     bottomLeft: Radius.circular(30),
//                     bottomRight: Radius.circular(30),
//                   ),
//                 ),
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: SizedBox(
//                         height: 50,
//                         child: ElevatedButton(
//                           onPressed: () => Navigator.pop(context),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.transparent,
//                             shadowColor: Colors.transparent,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(25),
//                               side: const BorderSide(
//                                 color: Colors.grey,
//                                 width: 1,
//                               ),
//                             ),
//                           ),
//                           child: const Text(
//                             'إلغاء',
//                             style: TextStyle(
//                               color: Colors.grey,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     ),
//   );
// }
